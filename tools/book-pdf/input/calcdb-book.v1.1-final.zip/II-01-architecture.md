# II-01. Architecture and compatibility boundaries

Book **v1.1** · 2026-11-16 · [Release record](00-book-release.md).

This chapter deepens I-01 into library contracts, owned state and executable paths. [Scope and context](00-scope.md), §§S1–S7, states the current product boundaries. The named experiments in A-02 decide unobserved ACE behavior; native acceptance remains unexecuted. The original supplied oracle identity is ACEDAO.DLL **16.0.20527.20016**. PRD-02 separately reports `Apartment` registration on Office C2R x64 **16.0.20527.20150**. Future captures identify the actually loaded components and host configuration; the two supplied reports are not interchangeable DLL-version evidence. The decision and implementation record remains in book-record.[^oracle]

The terms *qualified* and *established* use the [common terminology](book-record.md#terminology). The deciding native branches are named at the field, publication and crash boundaries below; these references specify implementation evidence, not completed native results.

**Requirement trace:** RQ-PROD-01, RQ-ARCH-01, RQ-PORT-01, RQ-OUT-01, RQ-OUT-02, RQ-SRC-01 and RQ-SRC-02 are owned here; this chapter supports RQ-PROD-02 (owned by I/II-13), and the value, storage, call, object-model and platform requirements are implemented through the contracts assigned to their detailed chapters. The full stable scope map remains I-16. **D-ARCH-1 — Decided.** One format description, ISAM engine, expression service, oracle and harness are fixed scope; the proposed physical library boundaries below are the recommended realization.[^scope]

## 1. Separate compatibility policy from implementation freedom

**RQ-PROD-01.** Rust is the implementation target. The library boundaries, ownership rules and pseudocode use language-neutral systems notation, so the design can also be understood in C with limited C++, C# or OCaml without assuming Rust-specific runtime behavior. This does not add a second implementation or change the one-core requirement.

A public call has three kinds of obligation. Its **surface policy** determines parameter handling, optional arguments, object state, result ownership and errors. Its **semantic operation** determines rows, expressions, constraints, transactions and observable effects. Its **physical operation** determines pages, encodings, references, native locks and persistent outcomes. These obligations are separate enough to test, but none may be omitted because another layer produced the right final rows.

For example, `DAO.Recordset.Update` is not implemented as a generated SQL statement. The DAO policy selects the edit buffer and applicable options, then invokes the same ISAM mutation and constraint services that a SQL action operator uses. Their selection and failure policies may differ; their row encoder, index-key generator and allocation ownership must not. Conversely, an ADO Recordset cannot inherit a DAO cursor policy merely because both eventually read the same table. Its negotiated cursor behavior, errors, events and lifecycle belong to the ADO adapter (I-12).

The native file determines what a durable representation may be. CalcDb chooses a sparse cache map, frame pool, descriptor cache and operator structures. Those structures may be replaced after measurement while keeping the observable contract. The file's sort descriptor may select a key encoder; the oracle's build label may not secretly select whichever behavior happens to pass a test. If evidence from actual builds conflicts, record the conflict and select a declared target rather than adding an invisible environment switch.

The shared semantic value is the **platform's real Automation VARIANT and real BSTR**, including the 24-byte Windows x64 VARIANT layout. CalcVBA and CalcDb use that exact platform representation ([scope](00-scope.md), §S3). A borrowed record span can postpone decoding and preserve native precision; any value crossing the shared semantic boundary obeys K-VALUE/K-STRING. II-02 specifies that distinction and its ownership algorithms.[^values]

### Scope and source boundaries

**RQ-OUT-01.** Forms, reports, macros and stored database modules retain their native catalog identities, content and reference closure. The admitted catalog and content-reading paths remain available; opening or changing a database does not make these objects executable. II-04's protected-region/reference descriptors and II-06's native catalog records carry their ownership through ordinary edits. Unknown relocation rules prevent an unsafe move before publication. A host-opted-in UDF instead uses II-10/13's explicit resolver and retained host binding; stored module discovery never becomes an implicit function-registration or execution route. Acceptance compares preserved content and reachability and checks that the operation caused no stored-code invocation.

**RQ-OUT-02.** The supported native format boundary is Jet 4/ACE. Detect a Jet 3 signature before selecting a mutating profile and retain the unsupported-format outcome. The libraries expose the required local caller/host interfaces; a database server role and its network service protocol are outside this product. The SQL grammar and binder implement Access behavior and documented/native-admitted forms. A proposed convenience extension cannot introduce a CalcDb-only SQL dialect. These exclusions do not excuse refusing an operation inside the declared Jet 4/ACE, DAO, ADO or Access SQL scope.[^scope]

The following boundaries apply to every library and public route. Their detailed object, SQL, locking and interop policies remain in the owning chapters.

| Area | Current scope | Authority |
| --- | --- | --- |
| ADO | ACE database-provider strings; connectionless Recordsets and Streams, including `Provider=MSPersist` persistence. Other non-ACE providers, including an omitted/default database provider, receive named, counted not-modelled refusals. No system-ADO pass-through. The host selects which ADODB uses it routes to CalcDb. | PRD-03 and owner correction; scope §S2 |
| MDB security | Unsecured/default-Admin files and unchanged access-control bytes. `WITH OWNERACCESS OPTION` remains supported under default Admin, with its behavior decided by R-SQL-2/SQL-OWNERACCESS and R-DAO-1/DAO-SEC. Named logons, supplied workgroup files, account/group changes and permission checks that would deny access receive named, counted refusals. Secured-workgroup behavior is neither initial nor later scope. | PRD-04 and owner correction; scope §S2 |
| Text index keys | General, General–Legacy and the Access 97 General variant where admitted Jet 4/ACE files need it. Other orders retain reading/full scans; indexed Text seeks and key writes receive named, counted refusals. | PRD-05; scope §S2 |
| In-process sharing | ACE semantics in phase 1: distinct Workspace/Connection lockers, concurrent private change sets, native conflict granularity and retry-then-error behavior. Commit and rollback preserve other lockers' accepted changes. | PRD-01; scope §S4 |
| Threading | Windows `Apartment` registration and ordinary COM delivery; host functions use the supplied provider reference. CalcDb defines no CalcVBA-specific or host-specific thread policy. | PRD-02; scope §S4 |

**RQ-SRC-01/02.** Each physical rule or behavior policy records its exact documentary/reference material or public native capture and its evidence class. Use the public documentation and identified ACE observations, the permitted exact Jackcess materials with their licence/notice obligations, and mdbtools file-format facts only when consulted. No mdbtools material was used in this book. No proprietary decompilation/disassembly or direct excluded FrankenSqlite/asupersync source, repository, package, mirror or external extract enters that evidence path; their reviewed attached reports supply concepts only. A-01 records what was inspected and permits factual use separately from any future adaptation. Build inputs and generated resources retain that provenance too. II-15's corpus and II-16's implementation records preserve it when a hypothesis becomes an observed rule.[^source-rules]

## 2. Libraries and the dependency rule

A library may depend only on the contracts below it in Figure F-01 (I-01), or on an explicit interface owned by that lower boundary. A callback interface does not license an arbitrary upward call: its allowed inputs, ownership, thread and effects must be declared. The composition root connects implementations at startup; it is the one place allowed to know both the abstract service and the platform adapter.

| Library or contract group | Owns | Consumes | Must not do |
| --- | --- | --- | --- |
| Shared foundation | Exact Automation types/ownership, shared conversions/functions, type descriptors and semantic status values | Published platform Automation ABI and shared allocator services | Import the VBA interpreter merely to convert a scalar; invent a compact substitute shared VARIANT |
| Engine contracts | Handles/generations, resource budgets, effect interfaces, typed failures, evidence identifiers | Foundation declarations only where values are needed | Discover global filesystem, scheduler, host or registry services |
| Format | Variant descriptions, checked codecs, structural rules, key/row/page inspection | Byte spans, format descriptors, explicit bounds and allocator budget | Open a file, acquire an OS lock, infer SQL policy |
| Pager/storage | File sessions, stable frames, pins, dirty images, I/O receipts, allocation incarnations | Effect contracts and checked format primitives where necessary | Decide DAO EOF or SQL transaction semantics |
| Transaction and ISAM | Workspace participants, row identity, cursor mechanisms, constraint/edit mechanics, native page changes | Pager, format/key codecs, immutable schema/constraint descriptors | Bind SQL names, activate COM objects, discover host functions |
| Catalog | Native catalog bootstrap, schema/property/QueryDef interpretation and generation dependencies | ISAM primitives with explicit bootstrap descriptors | Require SQL binding to read the structures the binder itself needs |
| Expression | Bound scalar nodes and context-specific evaluation over shared CalcVBA semantics | Foundation values/functions, explicit resolver/effect interfaces | Find a host globally or invoke host code from an engine worker |
| SQL | Access grammar, binder, actual plans, operators, action/DDL coordination | Catalog, ISAM, expression service and bounded temporary storage | Maintain an independent storage engine or hidden saved-query database |
| DAO/ADO policies | Real objects, collections, per-surface state and error/event adaptation | Relevant catalog/ISAM/query/transaction services | Send a simple table cursor through SQL; equate Close with final Release |
| Native/portable adapters | Public COM entry, allocation services, host integration, actual I/O/locks/storage | Contracts they implement and public platform interfaces | Leak platform I/O into portable core libraries or transport local COM pointers through a VFS broker |
| Oracle and differential harness | Requests, captures, comparison, reduction, corpus and cost evidence | Public callers and instrumented engine contracts | Replace unknown ACE behavior with CalcDb's preferred invariant |

The table defines responsibilities, not a requirement for eleven independently shipped binaries. A systems implementation can group tightly coupled code for inlining or packaging while mechanically preserving forbidden imports. Avoid per-field plugin lookup: an immutable service table or statically specialized composition can supply stable functions without changing the contract. A runtime-selected storage backend is a connection-level decision, not a reason to rediscover capabilities on every `Fields(i).Value`.

The catalog/ISAM seam deserves an explicit bootstrap rule. A format profile supplies the minimal descriptors needed to traverse the native system structures. The catalog interprets those rows and produces ordinary schema descriptors. ISAM accepts the resulting descriptors and validates their generations; it does not call back into the binder to learn what a page means. Cross-table constraints similarly use prepared relation/constraint descriptors and lower-level lookups, with expression evaluation performed through the explicit operation coordinator. No hidden catalog singleton completes a dependency cycle.

Dependency checks operate at two levels. First, build the portable core with platform adapters absent, including wasm32. Second, inspect imports and effect calls: an accidental direct clock read can survive a successful portable build and still invalidate deterministic replay. The only approved escape is a named effect interface whose production and controlled implementations expose the same outcome model (K-IO, K-EVIDENCE). This is an architecture check, not evidence of ACE compatibility.

## 3. Composition and explicit environment

An engine instance is created from a validated service bundle. The following structures are neutral design notation; names describe required information rather than existing CalcVBA APIs.

```text
EngineServices {
    value_abi: PublishedAutomationContract
    allocation: AllocationDomains
    files: FileEffects
    locks: LockEffects
    temporary: TemporaryStorage
    clock: ClockEffects
    entropy: EntropyEffects
    scheduling: ScopedWorkEffects
    host: Optional<HostServices>
    diagnostics: EvidenceSink
}

DatabaseSession {
    file_identity: FileIncarnation
    format: ValidatedFormatProfile
    admission: OpenLease
    pager: PagerHandle
    catalog_generation: Generation
    session_policy: SurfaceNeutralPolicy
    lifecycle: Open | Closing | Closed | Uncertain
}

OperationContext {
    operation_id: StableOperationId
    caller_thread: CallerThreadToken
    owner: OperationOwner
    services: Borrow<EngineServices>
    budget: ReservationAccount
    cancellation: Borrow<CancellationState>
    evidence: Optional<TraceScope>
    failure_context: FixedContext
}
```

`EngineServices` is retained by the engine's lifetime owner. `OperationContext` is borrowed for one blocking call and is not stored in a returned Recordset, pending transaction or callback registry. Those objects retain stable owner/service handles and construct a new call context on their next invocation. The caller-thread token identifies the thread on which this CalcDb call is delivered; it does not prescribe the thread on which a supplied provider reference runs. This prevents a continuation from retaining a dead stack reference while still allowing a cursor to keep its decoded row state or query iterator between calls.

The published Automation contract records actual size, alignment, field offsets, calling convention, array stride and allocator pairing for the target. Boundary checks use the target's actual declarations and allocator rules. Windows uses its real services; the portable stand-in supplies the required local interface and allocation behavior. This design does not assume the stand-in already exists. I-FOUNDATION-1 establishes the published declarations and executable minimal client; the required surface is enumerated in I-13.

A format profile is selected from validated file evidence and options. It describes page size, structural variants, supported scalar/key codecs and preservation restrictions. It contains no guessed “writer build” field. A session's admission lease is tied to the actual open file object and retained until the associated resources settle. A path, timestamp or lock-file name is not equivalent to that lease. I-09 makes the initial exclusion and reader-only handle candidates explicit; R-LOCK-1/2 determine whether those candidates admit the required native callers.

Capability discovery happens before the operation whose correctness requires it. If a backend cannot express the needed flush or exclusion, that operation has an explicit unsupported or uncertain outcome according to the chosen surface policy; it cannot return success and silently weaken the contract. During development this is a visible coverage failure for an in-scope operation. Capability tables describe genuine environment differences and later-phase features, not a device for shrinking the product denominator.

## 4. Resource scopes, handles and validity

The ownership tree describes cleanup obligations; it is not the COM object graph. A Workspace may coordinate transactions across database participants; a Recordset may retain a cursor after a parent interface is released; an enumerator can keep a collection object alive after its database resources are closed. Exact visible behavior belongs to R-DAO-1/R-ADO-1, while the engine must support those distinctions without use-after-free or resource leaks.

| Owner | Retained state | Settlement responsibility |
| --- | --- | --- |
| Engine/host | Services, factory registrations, value/allocator domains and immutable definitions | Stop new work; settle owned work; revoke registrations only when object lifetime permits |
| Workspace or ADO session coordinator | Transaction levels, participant identities, rollback obligations and public outcome receipts | Apply evidenced commit/rollback/Close policy; retain uncertainty when persistence is unresolved |
| Database session | Open lease, pager, catalog generations and native file state | Deny incompatible new work, drain pins/work and close only after obligations settle |
| Cursor/query | Position and population state, identity family, edit state, retained plan/row buffers | Settle cursor-specific effects; preserve surface-valid object state after resource Close |
| Call/statement | Scratch, temporary reservations, transient pins, worker group and staged diagnostics | Publish one terminal outcome; release resources in dependency order |
| COM reference | Identity and reachable object allocation | Finalize object allocation when references permit; never infer successful database rollback from destruction |

Use handles containing owner identity, slot and generation where slots or storage can be reused. For pages, add the file/allocation incarnation and version identity where relevant. A raw pointer is usable only within a proven borrow whose owner, pin and generation remain valid. A fresh allocation at the same address does not revive an old cursor bookmark or page view. Public bookmark representation remains an independently observed DAO/ADO ABI (I-07); internal handles do not define it.

Memory validity and semantic validity are different predicates. A schema descriptor can remain allocated after DDL invalidates it. A saved plan can retain all of its memory but no longer have the same function registry or sandbox interpretation. A field span can remain pinned while a cursor has moved to another logical row. Each use checks the relevant generation at its documented boundary; the hot scalar path does not need a global lookup for every primitive access when the enclosing call has already validated and pinned the owner.

Reservation precedes construction. Before decoding a long string, collecting a batch or making dirty copies, the owner reserves the maximum checked capacity needed for that step. Charge frame pins and historical retention separately from owned heap bytes; avoiding a copy can still increase working set by retaining a page. Reservations transfer between engine-owned handles and release on a defined terminal path. At public VARIANT/BSTR ownership handoff, settle the engine admission charge: canonical client values cannot carry a private reservation, and the engine may not observe their eventual free. Report outstanding client-owned bytes only when the allocator/host can actually observe them; do not pretend they remain enforceable engine memory. Integer overflow, an invalid encoded length and exhausted capacity are different failures and must not all appear as a generic allocation error (K-ADMISSION).

Final releases can execute external object code. Therefore, an internal mutex is not held while clearing a VARIANT that may release an interface, invoking an event sink or destroying host-owned state. Move pending releases into an owned cleanup list, leave the protected region, then perform them. An ordinary database logical lock may legitimately remain held across a public call or callback if ACE's policy requires it; the prohibition concerns internal latches and uncontrolled reentrant code, not an invented rule that all native locks vanish before VBA entry.

## 5. The direct DAO read path

Figure F-02 in I-02 shows the VBA-to-page sequence. The implementation keeps public policy and physical work explicit so the first-priority path can be measured without requiring SQL or a task scheduler.

A Field object caches its validated field ordinal and parent identity. Name lookup remains a collection policy with the target's comparison and errors; once lookup has produced a Field interface, subsequent value calls need not repeat a name search unless the observed collection semantics require rebinding. `MoveNext` advances the ISAM cursor, invalidates row-local views and reuses their capacity. It does not unconditionally count or materialize the entire recordset.

```text
ReadPublicField(field_object, context) -> OwnedAutomationValue or Failure
    input: a live interface and one blocking call context
    output owner: caller, using the published Automation allocator rules

    policy = validate_field_surface_state(field_object)
    cursor = validate_owner_handle(field_object.cursor_handle)
    source_guard = cursor.acquire_public_field_source(field_object.ordinal, policy)
    if source_guard failed:
        return surface_failure(source_guard.failure, policy)

    if source_guard selects AcceptedEditValue:
        result = CaptureValueStructural(source_guard.retained_cell,
                                        policy.value_copy, context.operation)
    else if source_guard selects UnsetEditField:
        result = project_unset_field_under_native_getter_policy(source_guard, policy)
        # Do not reevaluate a default or allocate another generated value here.
    else:
        # UnchangedEditField uses the edit's retained original span.
        # CurrentStoredField uses the current row and its stable page/read source.
        borrowed = source_guard.field_span(field_object.ordinal)
        checked = validate_span_and_native_type(borrowed, policy.descriptor)
        if checked failed:
            result = checked.failure
        else:
            reservation = context.budget.reserve(checked.output_bound)
            if reservation failed:
                result = reservation.failure
            else:
                result = materialize_real_automation_value(checked, reservation)

    retain result under the operation while settling source_guard outside latches
    after any foreign copy or cleanup, validate the field/edit/cursor continuation
    transfer the owned result only if that continuation permits publication
    otherwise settle or retain exact residual owners and return the selected failure
```

The getter first selects the public edit or navigation state, as required by II-07 §13. An accepted edit cell is retained through a locally owned cell/version before any copy can reenter; replacement of the live cell cannot clear that retained value. An unchanged edit field reads its retained original, and an unset new field follows the native getter policy. It does not fall back to the cursor's previous navigation row. R-CURSOR-1/CUR-EDIT and R-DAO-1/DAO-ID/DAO-LIFE decide the projection and error at each Edit/AddNew/CancelUpdate/Update transition.

The guard owns any cell version, pin and scratch view used by the source. The result never points into those bytes. Materialization either transfers one fully initialized owned value or returns a failure with all partial resources settled. Public state/error adaptation occurs once at the boundary; a cleanup error cannot erase an earlier uncertain persistent outcome. II-02 defines `CaptureValueStructural`, BSTR/SAFEARRAY and ByRef rules, and [II-03](II-03-pager.md) defines the guard/pin mechanics.

For a fixed-width scalar already on a valid cached row, the design target is a bounded amount of local work plus the actual COM call: validate state, locate the field and copy/convert the required value. Whether this path allocates zero engine objects must be measured, not asserted for every type or runtime. A BSTR result ordinarily needs independently owned output storage; a decoded cache saves work only if repeated access compensates for retained capacity and invalidation. The cost of lookup, decode and ownership transfer is recorded separately by R-STRING-1.

Complexity is proportional to the field's encoded/decoded length for materialization, plus any page/LV traversal and actual lookup work. Row-directory decoding can be reused for repeated access, but a hidden whole-row reconstruction on every scalar call is not acceptable without a measured reason. Failures at each reservation/decode step must leave cursor position and public error state as the selected ACE policy requires; the helper itself does not invent advancement or retry behavior.

## 6. Mutation preparation and publication

**RQ-ARCH-01, RQ-CALL-03/04 and RQ-STORE-04.** A mutation is a semantic operation plus a prepared native change set. One `PreparedMutation` binds the row identities, checked old values, schema/allocation generations, constraints, encoded new rows/keys, protected regions, page images and transaction obligations needed for publication. It contains no raw borrow whose pin has already been released.

Preparation may be incremental when expression effects and failure timing require it. “Prepare the entire physical write set” does not mean “evaluate all user expressions early.” After each permitted semantic boundary, prepare the physical changes that can be planned without moving or repeating a callback. An action whose candidates change under its own index updates uses the evidenced stable traversal or ordered identity spool in I-11, rather than an unconditional pre-evaluation pass.

```text
ApplyPreparedMutation(prepared, context) -> OutcomeReceipt
    inputs: owned prepared images; admitted file participant; selected statement policy
    invariant: no engine publication has occurred merely by preparing images

    dependencies = revalidate prepared owner, admission and semantic/physical inputs
    if semantic inputs or owner/admission no longer permit this continuation:
        return policy-selected retained-view continuation or invalidation disposition
               retaining accepted values, generated tickets and effects; never replay them
    if only physical images or placement changed:
        prepared = bounded_effect_free_reprepare(prepared.accepted_semantic_receipts,
                                                  qualified fresh protected inputs)
        if no admitted preparation succeeds:
            return policy-selected failure retaining the original accepted outcomes

    retain the owning locker's selected local claims under finite native retry policy
    reserve remaining transaction and cleanup obligations
    attach accepted delta and prepared images to the owning rollback/statement frame
    if the selected boundary keeps this unit private:
        return its accepted private receipt; submit no native write

    hand the selected publication unit to II-08's ResolutionAttempt
        preflight local claims across its known participants before any file gate
        use PreparePublicationProgram(delta, scope, mode, profile, budget)
            to own the short gate, rebuild over the fresh base and seal the program
        on physical expansion, replan before submission without replaying accepted effects
        execute once with owned progress; retain every uncertain persistent effect
        resolve visibility, transaction frame and public outcome by policy
        after success, release admission holds/gates before deferred foreign releases
    return the owned resolution receipt
```

A changed page generation alone is not a row conflict. Revalidate the stable row identity, accepted values, constraints and exact key-profile/table/index incarnations first. When those semantic dependencies remain valid, a fresh protected page or a relocated row can require new physical images without demanding another UDF, default expression or generated-value allocation. Reprepare only that physical closure, retaining every accepted semantic/effect receipt and a bounded retry budget; II-05 §8.2, II-07 §15–16 and II-09 give the concrete cases. Semantic invalidation instead follows the evidenced continuation/failure policy. Once this mutation's native program has submitted an effect, its registered coordinator owns further advancement or resolution; this prepublication reprepare path is not a generic restart of a partly executed write program.

The preferred starting write program uses one final image per page per publication unit. The data-versus-index order, other publication dependencies and implicit-write timing are provisional. I-08/II-08 describe the competing programs; R-CRASH-1/CRASH-ORDER-DATA, CRASH-ORDER-INDEX and CRASH-ORDER-REPEAT decide their native order, while R-TXN-1/TXN-FLUSH-LIVE distinguishes implicit-write timing. Repeated-image compilation remains an alternative if the evidence requires it. Any needs-repair marking must use a native field and protocol established by R-CRASH-1/CRASH-PROGRAM observations. Submitted write order does not by itself imply persistence order. Ordinary commit and `dbForceOSFlush` retain their distinct acknowledgement and survival obligations ([scope](00-scope.md), §S5).

The receipt records logical progress, public acknowledgement eligibility and persistent uncertainty separately. An exception from a later flush cannot pretend that earlier writes never occurred. Multi-file Workspace coordination retains a receipt per participant; this architecture does not imply a distributed atomic commit protocol. A Workspace or Connection is a local locker, and several lockers may retain private changes. A short publication gate protects fresh-base reconstruction and native publication, not the lifetime of a transaction. Rebase applies accepted effects to the latest committed images without repeating callbacks or generated-value choices. Rolling back unpublished work removes only the owner’s overlays and reservations; it never restores a stale whole page over a sibling’s commit. Any rollback that requires native writes uses the same receipts and failure accounting as forward work (R-TXN-1/TXN-LOCAL and FAIL-OWNER; II-09 §23).

R-TXN-1/TXN-LOCAL decides the fresh-base input and local conflict policy used by `ApplyPreparedMutation`. Later external-writer contexts add R-LOCK-4/WRITE-ORIGINAL and WRITE-REBASE; local acceptance does not decide those native protection intervals.

D-UNDO-2 is outside planned work. It remains a recorded idea to reconsider only if real write programs show a useful recovery window. D-UNDO-1 remains unchanged: ACE-first reopening cannot depend on a private undo file. Any future CalcDb-first aid must validate file identity, integrity, extent and rollback eligibility under exclusion, read the complete file, require every uncovered page unchanged and every covered page equal to its before-image or intended new image, and otherwise discard the record.[^recovery] It must never undo a commit that ACE's survival rules require retaining. The predicate does not claim to prove that nobody changed and restored bytes in the past ([scope](00-scope.md), §S5).

Crash parity is the target: after a crash, CalcDb leaves a state no worse than ACE at the corresponding point, including commit survival and native repair marking. The preferred direction records ACE's writes and flushes with their contents, reconstructs crash states offline, classifies them through ACE, Access and Compact & Repair, and gives CalcDb's crash states to the same openers. Observation/control tools, including a kernel driver, may be built without decompiling proprietary binaries. Exact classification is ambitious and may not be fully achievable. R-CRASH-1/CRASH-RELATION and CRASH-CAPTURE carry the deciding comparison. Its method, precise pass condition and treatment of writes whose classes cannot be established are resolved during implementation (PRD-07).

## 7. Callbacks, workers and reentrant continuation

A public operation blocks its caller. Windows classes use `Apartment`, matching the registration reported in PRD-02. COM delivers properly marshaled calls to the object's apartment. The priority path is one STA running CalcVBA or real VBA in Excel. Host functions are invoked through the supplied provider reference; COM apartment rules determine where that provider executes. CalcDb does not compare the entry thread with a CalcVBA runtime thread or choose its own delivery policy. The expression service uses shared scalar primitives without requiring the interpreter for ordinary values. Host discovery and activation belong to supplied services, not global scans inside the evaluator (D-CALL-1, D-UDF-1; K-THREAD; [scope](00-scope.md), §§S3–S4).

Before an external callback, finish the current internal critical section. Capture by-value inputs through II-02's `CaptureValueStructural`: no-foreign-code copies on the calling thread, one AddRef for one object, or element-wise copying with safe backing and validation after callout. An unsupported safe-capture form receives an explicit disposition. Legal ByRef arguments retain their actual alias/writeback contract. Retain stable object/plan handles and the generation vector required afterward; these engine tickets do not pretend to version caller-owned storage. Record the callback's ordinal in the operation trace. Invoke the supplied provider reference once, outside internal latches. Preserve its returned value or error before performing any diagnostic call that might overwrite error information.

After the callback, validate cursor, catalog, transaction, function-registry, sandbox and other retained-plan dependencies that the callback could change. A still-live pointer is insufficient. If reentry closed or changed the operation's environment, apply the evidenced invalidation/Close policy. Do not call the UDF again in an attempt to reconstruct state. If a new prepared native change cannot be reconciled, return the proper failure with the original callback effect retained in the evidence.

Workers are children of the call or a specifically named retained owner. Their inputs are stable owned values or explicitly pinned immutable pages; their outputs are ordinal-labelled, bounded work units. Native Automation copy and foreign reference management obey their platform contracts and the applicable COM apartment rules. I-FOUNDATION-1 establishes the services' concurrency and reentry behavior; ownership of distinct values alone is not evidence of a thread-safe native copy service. Internal workers do not invoke caller-bound foreign code, and CalcDb adds no CalcVBA-specific thread rule (II-02/II-13). No internal latch is held across foreign retain/release. The caller consumes them according to the accepted serial order and chooses errors according to that order. A worker cannot expose an I/O or conversion error early merely because it completed early. Double accumulation retains the serial fold order; deterministic partition sums alone do not satisfy K-PAR.

Background prefetch owns its reservation, cancellation and eventual buffer disposition. Closing a cursor marks the work unwanted, joins or otherwise settles it through the adapter contract, and releases buffers only after no completion can still reference them. Browser VFS timeouts follow the same rule: a timeout does not revoke a broker's access to a shared buffer or prove that a write did not happen. The broker provides storage effects only; it does not transport local COM interfaces or run VBA remotely.

## 8. Errors, close and stable public outcomes

An internal failure contains stable operation identity, phase, object/resource context and cause, plus completed/uncertain effects. Public adapters translate it using the evidence for the actual surface and operation. They retain distinctions among a bad argument, invalid object state, constraint violation, resource exhaustion, host exception, I/O failure and uncertain persistence. A generic “failed” status cannot carry enough information for correct continuation.

DAO and ADO error collections have different owners and lifetimes; COM also exposes HRESULT, IErrorInfo and dispatch EXCEPINFO/argument-error data. The portable stand-in must supply those channels and their allocation/lifetime rules, not merely an integer error return. I-12/I-13 and R-ERR-1 define the exact capture and translation behavior. Error formatting is outside internal latches and must not allocate unbounded diagnostic strings while handling an allocation failure.

Close is a state transition that can release database resources while references remain. Final Release is an ownership event that can occur much later. Maintain explicit open/closing/closed/uncertain engine state and an independent COM reference count. Reentrant Close sees a defined transition, not partially destroyed memory. Under Windows `Apartment` registration, a properly marshaled final Release is delivered through COM to the object's apartment, including rollback and sink release. Pending commit/rollback obligations settle according to Workspace policy; the destructor cannot silently report them as completed. The .NET probes compare these lifetime outcomes with ACE rather than deriving them from a CalcVBA host policy. Cleanup failures retain the primary error and persistent uncertainty in the internal receipt, while the surface exposes the evidenced public combination.

After a successful commit, publish its resolved state and release the hold on new views and the publication gate before draining deferred foreign releases. A destructor that opens a new recordset then enters against the committed state. The drain runs outside internal latches and retains the commit receipt; a later cleanup failure cannot replay or undo that commit (PRW-35; II-08 §19, II-09 §12).

A returned owned value is complete before the operation publishes success. A returned interface already owns its reference. An enumerator's yielded VARIANT contains the required ownership, and ADO event connection points retain/release sinks through the same real interface rules. These details can be implemented in shared helpers, but they remain observable parts of the object model rather than optional adapter conveniences.

## 9. Later capabilities use these seams

Later scope changes the supported contracts without adding another engine. Encryption attaches to format-aware storage transforms, key ownership and protected temporary-storage policy; cache identity includes the relevant database/key domain. Linked tables supply source/capability descriptors and cursor/transaction adapters; they do not imply universal pushdown or cross-source durable atomicity. Complex fields reuse catalog, row/LV and cursor ownership while retaining kind-specific storage and update policies.

CalcDb's later compact/repair implementation is a separate destination-building operation with explicit relocation and opaque-reference evidence. It is not needed to run the initial native acceptance test T-COMPACT-1. OLE DB and ODBC expose the existing services through their own negotiated ABI, handle and diagnostic rules. Initial CalcDb ADO serves its ACE-provider and connectionless persistence scope internally. It remains separable for the later external OLE DB provider, which is not an initial dependency (PRD-03).

The four cross-process sharing steps use one admission/freshness/publication interface from the first writer. Initial exclusion and reader-only sharing are real native protocols. ACE in-process semantics, including local-owner rebase, are initial scope even when the file lease excludes other processes. Later reading beside ACE and shared writing add external byte-lock and cache-coherence policy; in-process page versions cannot reconstruct a page ACE has already overwritten. Every later combination has its own experiments in A-02 and implementation prerequisites in I-16, instead of making all later work wait for shared writing.

## 10. Acceptance and cost evidence

Acceptance checks the architecture at its observable seams. It does not require a test that merely repeats a structure definition. The following cases catch failures that a successful SELECT or COM construction would miss.

| Check | Discriminating case and required result |
| --- | --- |
| One storage/evaluator path | Equivalent direct DAO and SQL operations reach the same row/key/constraint services while retaining their surface-specific failure policy; traces identify actual calls rather than simulated labels. |
| Portable core | Build format/ISAM/catalog/expression/SQL without native adapters for wasm32; a dependency/effect audit finds no direct platform I/O or hidden time/randomness. |
| Preserved front-end scope | Keep forms/reports/macros/module content and native references across admitted reads and edits; no stored-code invocation occurs. Host functions require the separately admitted resolver path. |
| Format/dialect/source boundaries | A Jet 3 input cannot reach a native mutator; query capability follows the declared Access grammar. Each admitted rule/resource has permitted material or native-capture provenance, and protected unknown content stays preserved. |
| Exact shared value ABI | Native and managed callers exercise real VARIANT/BSTR ownership; II-02's size/offset/stride, nested-array and ByRef cases pass on the declared target. |
| Direct row loop | Actual VBA/COM calls iterate narrow/wide, text/LV and indexed fixtures; measurements separate crossings, lookups, decode, allocation and pin work. Field getters after Edit, AddNew, failed assignment, CancelUpdate and Update select accepted cells, retained originals or native unset state before navigation storage. |
| Lifetime versus Close | Hold Field, Collection and enumerator references across Close/Release and reentry; results match captured surface policy without leaked leases or stale borrows. |
| Callback continuation | A UDF closes/requeries or changes schema/registry state; the provider is invoked once, outside latches, through its supplied reference; COM delivery follows the selected native policy, and continuation revalidates dependencies before proceeding. |
| Failure ownership | Exhaust reservations, fail partial I/O, cancel workers and interrupt cleanup; no buffer/lease escapes its owner, and persistent uncertainty remains visible. |
| Normal completed write | Target: clean native structure/content and ordinary ACE/Access opening without repair. T-COMPACT-1 maps each write to possible damage and the observers expected to detect it; implementation completes that list and its precise pass condition. Repair must not hide a damaged original output. |
| Interrupted write | Target: no worse than the corresponding ACE crash, with the same commit-survival rules including forced flush. Capture/reconstruct both engines' states and compare the same native opener outcomes. Exact classification and acceptance are settled during implementation; no private undo file is assumed. |
| Same production logic under control | Deterministic adapters replay actual state transitions, detect trace divergence and preserve original failure evidence; native tests cover adapter behavior outside the simulator model. |

For the scalar row-loop path, record a cost vector rather than a promised time: engine allocations, owned bytes, copied bytes, decoded units, retained/pinned bytes, name-lookup probes, format branches, page reads, lock operations and public crossings. Bulk operators add rows/batches, comparisons, spill volume/passes and working-set peaks. Browser runs add bridge copies, storage rendezvous and linear-memory high-water mark. Charge owner-retained capacity to its lifetime; a faster call that retains every page can be worse for the workload.

The first accepted read slice establishes a baseline; R-STRING-1 compares materialization policies there. W-PROBE's basic native effects precede W-03, while full ACE crash instrumentation develops independently. Catalog bootstrap starts from R-ORACLE-1/R-FMT-1; expression/transaction/mutation dependencies attach only to the catalog branches that need them. ADO construction and policy research may proceed alongside DAO, with DAO receiving priority when effort conflicts. [II-03](II-03-pager.md) specifies the native page layouts, image/frame identities, I/O receipts and stable pin algorithms used by these paths.

## Sources and status

The algorithms and contracts in this chapter are proposed CalcDb design. Actual target behavior remains documentary, user-supplied or experiment-dependent as labelled. The cleared reports contribute generation-tagged ownership, reservation, scoped cleanup and replay concepts; they do not impose a runtime, WAL or isolation model.[^notes] Full exact source/use/licence metadata is in A-01; full deciding experiments are in A-02. Figures F-01 and F-02 appear in Part I and are rendered by the PDF build.

[^scope]: [B-SCOPE-11] [Scope and context](00-scope.md), §§S1–S7, is the book's scope statement. [U-PRD-01-09] `decisions.md` and [U-PRW-01-58] `work.md` govern this revision; compatible charter/integration material elaborates that scope. These are requirement sources, not native observations. A-01 records their provenance.
[^values]: [B-SCOPE-11] [Scope and context](00-scope.md), §S3, and [U-PRW-01-58] `work.md`, PRW-43, state the shared platform value agreement. Microsoft's [VARIANT declaration](https://learn.microsoft.com/en-us/windows/win32/api/oaidl/ns-oaidl-variant) supplies the native union structure; II-02 derives and checks its target ABI.
[^source-rules]: Supplied `gpt6pro-book-prompt.md`, “Source rules,” and [B-SCOPE-11] [Scope and context](00-scope.md), §S7, identify the nine canonical first-stage report parts as cleared concept input. Source authority and permitted-use constraints; exact cited materials and reuse classifications remain in A-01.
[^notes]: Supplied `asupersync-report.stage1-part1.md` §§1, 3, 6, 8; `asupersync-report.stage1-part2.md` §§2–4; `asupersync-report.stage1-part4.md` §§3–4; `frankensqlite-report.stage1-part3.md` §§8, 10. Cleared concept input only; no direct excluded repositories, packages or external extracts used.

[^oracle]: [U-OWNER-ACE] in A-01 records the owner-reported ACEDAO.DLL identity. [U-PRD-01-09] `decisions.md`, PRD-02, records the distinct Office C2R registration report; neither is a new native capture.
[^recovery]: [U-OWNER-RECOVERY] in A-01 and [B-SCOPE-11] [Scope and context](00-scope.md), §S5, retain D-UNDO-1's owner-specified predicate. PRD-09 leaves the optional aid outside planned work.
